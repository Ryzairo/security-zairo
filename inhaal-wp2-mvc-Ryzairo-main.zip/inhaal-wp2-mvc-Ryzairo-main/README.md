# werkplaats-2-inhaalopdracht-mvc
Template voor WP2 inhaalopdracht "evenementenagenda". Vul dit document aan zoals beschreven in de [opdracht](CASUS.md). 


Bronnen:

Software & Web Technology. (2021, July 12). Login & Registration with SQLite Database Using Flask | Tamil [Video]. YouTube. https://www.youtube.com/watch?v=RrtzalGsPFk

Clinton Daniel. (2023, April 4). Python Flask development with SQLite [Video]. YouTube. https://www.youtube.com/watch?v=m9hUC-WRclU

Code van klasgenuiten uit het vorige project "racy" 

chatgpt voor css styling
